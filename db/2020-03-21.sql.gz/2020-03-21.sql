-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: headless_cms
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache_content`
--

DROP TABLE IF EXISTS `cache_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_content` (
  `field` varchar(255) NOT NULL,
  `value` blob NOT NULL,
  `tag` varchar(255) NOT NULL,
  `context` varchar(255) NOT NULL,
  UNIQUE KEY `field` (`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_content`
--

LOCK TABLES `cache_content` WRITE;
/*!40000 ALTER TABLE `cache_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `field` varchar(255) NOT NULL,
  `value` text NOT NULL,
  UNIQUE KEY `key` (`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES ('admin','a:1:{s:2:\"id\";i:1;}'),('site','a:2:{s:4:\"name\";s:4:\"Nick\";s:16:\"default_langcode\";s:2:\"en\";}'),('theme','a:2:{s:5:\"admin\";s:7:\"default\";s:5:\"front\";s:7:\"default\";}');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `extensions`
--

DROP TABLE IF EXISTS `extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `extensions` (
  `type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `installed` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extensions`
--

LOCK TABLES `extensions` WRITE;
/*!40000 ALTER TABLE `extensions` DISABLE KEYS */;
INSERT INTO `extensions` VALUES ('core','Database',1),('core','File',1),('core','Form',1),('core','Manifest',1),('core','Matter',1),('core','Person',1);
/*!40000 ALTER TABLE `extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
  `langcode` varchar(10) NOT NULL,
  `language` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  UNIQUE KEY `langcode` (`langcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES ('en','English','International');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `page` varchar(255) NOT NULL,
  `owner` int(25) NOT NULL,
  `backtrace` blob NOT NULL,
  `category` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `rendered` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matter`
--

DROP TABLE IF EXISTS `matter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matter` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matter`
--

LOCK TABLES `matter` WRITE;
/*!40000 ALTER TABLE `matter` DISABLE KEYS */;
/*!40000 ALTER TABLE `matter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matter__file`
--

DROP TABLE IF EXISTS `matter__file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matter__file` (
  `id` int(25) NOT NULL,
  `owner` int(25) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `filetype` varchar(255) NOT NULL DEFAULT 'file',
  `location` varchar(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matter__file`
--

LOCK TABLES `matter__file` WRITE;
/*!40000 ALTER TABLE `matter__file` DISABLE KEYS */;
/*!40000 ALTER TABLE `matter__file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matter__person`
--

DROP TABLE IF EXISTS `matter__person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matter__person` (
  `id` int(25) NOT NULL,
  `owner` int(25) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matter__person`
--

LOCK TABLES `matter__person` WRITE;
/*!40000 ALTER TABLE `matter__person` DISABLE KEYS */;
/*!40000 ALTER TABLE `matter__person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matter_storage`
--

DROP TABLE IF EXISTS `matter_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matter_storage` (
  `type` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `fields` blob NOT NULL,
  PRIMARY KEY (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matter_storage`
--

LOCK TABLES `matter_storage` WRITE;
/*!40000 ALTER TABLE `matter_storage` DISABLE KEYS */;
INSERT INTO `matter_storage` VALUES ('file','File','This item creates the File matter.',_binary 'a:2:{s:8:\"filetype\";a:4:{s:4:\"type\";s:7:\"varchar\";s:6:\"length\";i:255;s:13:\"default_value\";s:4:\"file\";s:4:\"form\";a:4:{s:4:\"type\";s:6:\"select\";s:4:\"name\";s:9:\"file_type\";s:5:\"label\";s:4:\"Type\";s:7:\"options\";a:3:{s:4:\"file\";s:4:\"File\";s:5:\"image\";s:5:\"Image\";s:5:\"video\";s:5:\"Video\";}}}s:8:\"location\";a:3:{s:4:\"type\";s:7:\"varchar\";s:6:\"length\";i:255;s:4:\"form\";a:3:{s:4:\"type\";s:4:\"file\";s:4:\"name\";s:13:\"file_location\";s:5:\"label\";s:8:\"Location\";}}}'),('person','Person','This item creates the Person matter.',_binary 'a:2:{s:4:\"name\";a:4:{s:4:\"type\";s:7:\"varchar\";s:6:\"length\";i:255;s:6:\"unique\";b:1;s:4:\"form\";a:2:{s:4:\"type\";s:7:\"textbox\";s:10:\"attributes\";a:1:{s:4:\"type\";s:8:\"username\";}}}s:8:\"password\";a:3:{s:4:\"type\";s:7:\"varchar\";s:6:\"length\";s:3:\"255\";s:4:\"form\";a:2:{s:4:\"type\";s:7:\"textbox\";s:10:\"attributes\";a:1:{s:4:\"type\";s:8:\"password\";}}}}');
/*!40000 ALTER TABLE `matter_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `translations`
--

DROP TABLE IF EXISTS `translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `translations` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `string` text NOT NULL,
  `translation` text NOT NULL,
  `args` blob NOT NULL,
  `from_langcode` varchar(10) NOT NULL,
  `to_langcode` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `translations`
--

LOCK TABLES `translations` WRITE;
/*!40000 ALTER TABLE `translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `translations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-21 10:54:47
