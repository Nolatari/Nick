-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: headless_cms
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache_content`
--

DROP TABLE IF EXISTS `cache_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_content` (
  `field` varchar(255) NOT NULL,
  `value` blob NOT NULL,
  `tags` text NOT NULL,
  `context` varchar(255) NOT NULL,
  `maxage` int(10) NOT NULL,
  `created` int(10) NOT NULL,
  UNIQUE KEY `field` (`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_content`
--

LOCK TABLES `cache_content` WRITE;
/*!40000 ALTER TABLE `cache_content` DISABLE KEYS */;
INSERT INTO `cache_content` VALUES ('page.cache',_binary 'N;','','page',1800,1584820269),('page.config',_binary 'N;','','page',3600,1584820278),('page.error',_binary 's:273:\"<!-- Begin Page Content -->\n<div class=\"container-fluid\">\n    <!-- Page Heading -->\n    <div class=\"d-sm-flex align-items-center justify-content-between mb-4\">\n        <h1 class=\"h3 mb-0 text-gray-800\">404 - Page not found</h1>\n    </div>\n</div>\n<!-- /.container-fluid -->\n\";','','page',3600,1584820344),('page.footer',_binary 's:2489:\"        </div>\n        <!-- End of Main Content -->\n        <!-- Footer -->\n        <footer class=\"sticky-footer bg-white\">\n            <div class=\"container my-auto\">\n                <div class=\"copyright text-center my-auto\">\n                    <span>Copyright &copy; Nick the Headless CMS 2020</span>\n                </div>\n            </div>\n        </footer>\n        <!-- End of Footer -->\n        </div>\n        <!-- End of Content Wrapper -->\n        </div>\n        <!-- End of Page Wrapper -->\n        <!-- Scroll to Top Button-->\n        <a class=\"scroll-to-top rounded\" href=\"#page-top\">\n            <i class=\"fas fa-angle-up\"></i>\n        </a>\n        <!-- Logout Modal-->\n        <div class=\"modal fade\" id=\"logoutModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"exampleModalLabel\" aria-hidden=\"true\">\n            <div class=\"modal-dialog\" role=\"document\">\n                <div class=\"modal-content\">\n                    <div class=\"modal-header\">\n                        <h5 class=\"modal-title\" id=\"exampleModalLabel\">Ready to Leave?</h5>\n                        <button class=\"close\" type=\"button\" data-dismiss=\"modal\" aria-label=\"Close\">\n                            <span aria-hidden=\"true\">×</span>\n                        </button>\n                    </div>\n                    <div class=\"modal-body\">Select \"Logout\" below if you are ready to end your current session.</div>\n                    <div class=\"modal-footer\">\n                        <button class=\"btn btn-secondary\" type=\"button\" data-dismiss=\"modal\">Cancel</button>\n                        <a class=\"btn btn-primary\" href=\"login.html\">Logout</a>\n                    </div>\n                </div>\n            </div>\n        </div>\n        <!-- Bootstrap core JavaScript-->\n        <script src=\"themes/default/vendor/jquery/jquery.min.js\"></script>\n        <script src=\"themes/default/vendor/bootstrap/js/bootstrap.bundle.min.js\"></script>\n        <!-- Core plugin JavaScript-->\n        <script src=\"themes/default/vendor/jquery-easing/jquery.easing.min.js\"></script>\n        <!-- Custom scripts for all pages-->\n        <script src=\"themes/default/js/sb-admin-2.min.js\"></script>\n        <!-- Page level plugins -->\n        <script src=\"themes/default/vendor/chart.js/Chart.min.js\"></script>\n        <!-- Page level custom scripts -->\n        <script src=\"themes/default/js/demo/chart-area-demo.js\"></script>\n        <script src=\"themes/default/js/demo/chart-pie-demo.js\"></script>\n    </body>\n</html>\";','','page',3600,1584820269),('page.header',_binary 's:15933:\"<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n    <meta charset=\"utf-8\">\n    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\n    <meta name=\"description\" content=\"\">\n    <meta name=\"author\" content=\"\">\n    <title> - Nick</title>\n    <link href=\"themes/default/vendor/fontawesome-free/css/all.min.css\" rel=\"stylesheet\" type=\"text/css\">\n    <link href=\"https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i\" rel=\"stylesheet\">\n    <link href=\"themes/default/css/sb-admin-2.min.css\" rel=\"stylesheet\">\n</head>\n<body id=\"page-top\">\n<div id=\"wrapper\">\n    <ul class=\"navbar-nav bg-gradient-primary sidebar sidebar-dark accordion\" id=\"accordionSidebar\">\n        <a class=\"sidebar-brand d-flex align-items-center justify-content-center\" href=\"index.html\">\n            <div class=\"sidebar-brand-icon rotate-n-15\">\n                <i class=\"fas fa-laugh-wink\"></i>\n            </div>\n            <div class=\"sidebar-brand-text mx-3\">Nick <sup>1.0 alpha</sup></div>\n        </a>\n        <hr class=\"sidebar-divider my-0\">\n        <li class=\"nav-item\">\n            <a class=\"nav-link\" href=\"/\">\n                <i class=\"fas fa-fw fa-tachometer-alt\"></i>\n                <span>Dashboard</span></a>\n        </li>\n        <hr class=\"sidebar-divider\">\n        <div class=\"sidebar-heading\">\n            Interface\n        </div>\n        <li class=\"nav-item\">\n            <a class=\"nav-link collapsed\" href=\"#\" data-toggle=\"collapse\" data-target=\"#collapseTwo\" aria-expanded=\"true\" aria-controls=\"collapseTwo\">\n                <i class=\"fas fa-fw fa-cog\"></i>\n                <span>Configuration</span>\n            </a>\n            <div id=\"collapseTwo\" class=\"collapse\" aria-labelledby=\"headingTwo\" data-parent=\"#accordionSidebar\">\n                <div class=\"bg-white py-2 collapse-inner rounded\">\n                    <h6 class=\"collapse-header\">Configuration:</h6>\n                    <a class=\"collapse-item\" href=\"/?p=config&t=site\">Site settings</a>\n                    <a class=\"collapse-item\" href=\"/?p=config&t=appearance\">Appearance</a>\n                </div>\n            </div>\n        </li>\n        <li class=\"nav-item\">\n            <a class=\"nav-link collapsed\" href=\"#\" data-toggle=\"collapse\" data-target=\"#collapseUtilities\" aria-expanded=\"true\" aria-controls=\"collapseUtilities\">\n                <i class=\"fas fa-fw fa-wrench\"></i>\n                <span>Extensions</span>\n            </a>\n            <div id=\"collapseUtilities\" class=\"collapse\" aria-labelledby=\"headingUtilities\" data-parent=\"#accordionSidebar\">\n                <div class=\"bg-white py-2 collapse-inner rounded\">\n                    <h6 class=\"collapse-header\">Extensions:</h6>\n                    <a class=\"collapse-item\" href=\"/?p=extensions&t=install\">Install a new extension</a>\n                    <a class=\"collapse-item\" href=\"/?p=extensions&t=uninstall\">Uninstall extension</a>\n                </div>\n            </div>\n        </li>\n        <hr class=\"sidebar-divider\">\n        <div class=\"sidebar-heading\">\n            Addons\n        </div>\n        <li class=\"nav-item\">\n            <a class=\"nav-link collapsed\" href=\"#\" data-toggle=\"collapse\" data-target=\"#collapsePages\" aria-expanded=\"true\" aria-controls=\"collapsePages\">\n                <i class=\"fas fa-fw fa-folder\"></i>\n                <span>Pages</span>\n            </a>\n            <div id=\"collapsePages\" class=\"collapse\" aria-labelledby=\"headingPages\" data-parent=\"#accordionSidebar\">\n                <div class=\"bg-white py-2 collapse-inner rounded\">\n                    <h6 class=\"collapse-header\">Login Screens:</h6>\n                    <a class=\"collapse-item\" href=\"login.html\">Login</a>\n                    <a class=\"collapse-item\" href=\"register.html\">Register</a>\n                    <a class=\"collapse-item\" href=\"forgot-password.html\">Forgot Password</a>\n                    <div class=\"collapse-divider\"></div>\n                    <h6 class=\"collapse-header\">Other Pages:</h6>\n                    <a class=\"collapse-item\" href=\"404.html\">404 Page</a>\n                    <a class=\"collapse-item\" href=\"blank.html\">Blank Page</a>\n                </div>\n            </div>\n        </li>\n        <li class=\"nav-item\">\n            <a class=\"nav-link\" href=\"charts.html\">\n                <i class=\"fas fa-fw fa-chart-area\"></i>\n                <span>Charts</span>\n            </a>\n        </li>\n        <li class=\"nav-item\">\n            <a class=\"nav-link\" href=\"tables.html\">\n                <i class=\"fas fa-fw fa-table\"></i>\n                <span>Tables</span>\n            </a>\n        </li>\n        <hr class=\"sidebar-divider d-none d-md-block\">\n        <div class=\"text-center d-none d-md-inline\">\n            <button class=\"rounded-circle border-0\" id=\"sidebarToggle\"></button>\n        </div>\n    </ul>\n    <div id=\"content-wrapper\" class=\"d-flex flex-column\">\n        <div id=\"content\">\n            <nav class=\"navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow\">\n                <button id=\"sidebarToggleTop\" class=\"btn btn-link d-md-none rounded-circle mr-3\">\n                    <i class=\"fa fa-bars\"></i>\n                </button>\n                <form class=\"d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search\">\n                    <div class=\"input-group\">\n                        <input type=\"text\" class=\"form-control bg-light border-0 small\" placeholder=\"Search for...\" aria-label=\"Search\" aria-describedby=\"basic-addon2\">\n                        <div class=\"input-group-append\">\n                            <button class=\"btn btn-primary\" type=\"button\">\n                                <i class=\"fas fa-search fa-sm\"></i>\n                            </button>\n                        </div>\n                    </div>\n                </form>\n                <ul class=\"navbar-nav ml-auto\">\n                    <li class=\"nav-item dropdown no-arrow d-sm-none\">\n                        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"searchDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">\n                            <i class=\"fas fa-search fa-fw\"></i>\n                        </a>\n                        <div class=\"dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in\" aria-labelledby=\"searchDropdown\">\n                            <form class=\"form-inline mr-auto w-100 navbar-search\">\n                                <div class=\"input-group\">\n                                    <input type=\"text\" class=\"form-control bg-light border-0 small\" placeholder=\"Search for...\" aria-label=\"Search\" aria-describedby=\"basic-addon2\">\n                                    <div class=\"input-group-append\">\n                                        <button class=\"btn btn-primary\" type=\"button\">\n                                            <i class=\"fas fa-search fa-sm\"></i>\n                                        </button>\n                                    </div>\n                                </div>\n                            </form>\n                        </div>\n                    </li>\n                    <li class=\"nav-item dropdown no-arrow mx-1\">\n                        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"alertsDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">\n                            <i class=\"fas fa-bell fa-fw\"></i>\n                            <span class=\"badge badge-danger badge-counter\">3+</span>\n                        </a>\n                        <div class=\"dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in\" aria-labelledby=\"alertsDropdown\">\n                            <h6 class=\"dropdown-header\">\n                                Alerts Center\n                            </h6>\n                            <a class=\"dropdown-item d-flex align-items-center\" href=\"#\">\n                                <div class=\"mr-3\">\n                                    <div class=\"icon-circle bg-primary\">\n                                        <i class=\"fas fa-file-alt text-white\"></i>\n                                    </div>\n                                </div>\n                                <div>\n                                    <div class=\"small text-gray-500\">December 12, 2019</div>\n                                    <span class=\"font-weight-bold\">A new monthly report is ready to download!</span>\n                                </div>\n                            </a>\n                            <a class=\"dropdown-item d-flex align-items-center\" href=\"#\">\n                                <div class=\"mr-3\">\n                                    <div class=\"icon-circle bg-success\">\n                                        <i class=\"fas fa-donate text-white\"></i>\n                                    </div>\n                                </div>\n                                <div>\n                                    <div class=\"small text-gray-500\">December 7, 2019</div>\n                                    $290.29 has been deposited into your account!\n                                </div>\n                            </a>\n                            <a class=\"dropdown-item d-flex align-items-center\" href=\"#\">\n                                <div class=\"mr-3\">\n                                    <div class=\"icon-circle bg-warning\">\n                                        <i class=\"fas fa-exclamation-triangle text-white\"></i>\n                                    </div>\n                                </div>\n                                <div>\n                                    <div class=\"small text-gray-500\">December 2, 2019</div>\n                                    Spending Alert: We\'ve noticed unusually high spending for your account.\n                                </div>\n                            </a>\n                            <a class=\"dropdown-item text-center small text-gray-500\" href=\"#\">Show All Alerts</a>\n                        </div>\n                    </li>\n                    <li class=\"nav-item dropdown no-arrow mx-1\">\n                        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"messagesDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">\n                            <i class=\"fas fa-envelope fa-fw\"></i>\n                            <span class=\"badge badge-danger badge-counter\">7</span>\n                        </a>\n                        <div class=\"dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in\" aria-labelledby=\"messagesDropdown\">\n                            <h6 class=\"dropdown-header\">\n                                Message Center\n                            </h6>\n                            <a class=\"dropdown-item d-flex align-items-center\" href=\"#\">\n                                <div class=\"dropdown-list-image mr-3\">\n                                    <img class=\"rounded-circle\" src=\"https://source.unsplash.com/fn_BT9fwg_E/60x60\" alt=\"\">\n                                    <div class=\"status-indicator bg-success\"></div>\n                                </div>\n                                <div class=\"font-weight-bold\">\n                                    <div class=\"text-truncate\">Hi there! I am wondering if you can help me with a problem I\'ve been having.</div>\n                                    <div class=\"small text-gray-500\">Emily Fowler · 58m</div>\n                                </div>\n                            </a>\n                            <a class=\"dropdown-item d-flex align-items-center\" href=\"#\">\n                                <div class=\"dropdown-list-image mr-3\">\n                                    <img class=\"rounded-circle\" src=\"https://source.unsplash.com/AU4VPcFN4LE/60x60\" alt=\"\">\n                                    <div class=\"status-indicator\"></div>\n                                </div>\n                                <div>\n                                    <div class=\"text-truncate\">I have the photos that you ordered last month, how would you like them sent to you?</div>\n                                    <div class=\"small text-gray-500\">Jae Chun · 1d</div>\n                                </div>\n                            </a>\n                            <a class=\"dropdown-item d-flex align-items-center\" href=\"#\">\n                                <div class=\"dropdown-list-image mr-3\">\n                                    <img class=\"rounded-circle\" src=\"https://source.unsplash.com/CS2uCrpNzJY/60x60\" alt=\"\">\n                                    <div class=\"status-indicator bg-warning\"></div>\n                                </div>\n                                <div>\n                                    <div class=\"text-truncate\">Last month\'s report looks great, I am very happy with the progress so far, keep up the good work!</div>\n                                    <div class=\"small text-gray-500\">Morgan Alvarez · 2d</div>\n                                </div>\n                            </a>\n                            <a class=\"dropdown-item d-flex align-items-center\" href=\"#\">\n                                <div class=\"dropdown-list-image mr-3\">\n                                    <img class=\"rounded-circle\" src=\"https://source.unsplash.com/Mv9hjnEUHR4/60x60\" alt=\"\">\n                                    <div class=\"status-indicator bg-success\"></div>\n                                </div>\n                                <div>\n                                    <div class=\"text-truncate\">Am I a good boy? The reason I ask is because someone told me that people say this to all dogs, even if they aren\'t good...</div>\n                                    <div class=\"small text-gray-500\">Chicken the Dog · 2w</div>\n                                </div>\n                            </a>\n                            <a class=\"dropdown-item text-center small text-gray-500\" href=\"#\">Read More Messages</a>\n                        </div>\n                    </li>\n                    <div class=\"topbar-divider d-none d-sm-block\"></div>\n                    <li class=\"nav-item dropdown no-arrow\">\n                        <a class=\"nav-link dropdown-toggle\" href=\"#\" id=\"userDropdown\" role=\"button\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">\n                            <span class=\"mr-2 d-none d-lg-inline text-gray-600 small\">Valerie Luna</span>\n                            <img class=\"img-profile rounded-circle\" src=\"https://source.unsplash.com/QAB-WJcbgJk/60x60\">\n                        </a>\n                        <div class=\"dropdown-menu dropdown-menu-right shadow animated--grow-in\" aria-labelledby=\"userDropdown\">\n                            <a class=\"dropdown-item\" href=\"#\">\n                                <i class=\"fas fa-user fa-sm fa-fw mr-2 text-gray-400\"></i>\n                                Profile\n                            </a>\n                            <a class=\"dropdown-item\" href=\"#\">\n                                <i class=\"fas fa-cogs fa-sm fa-fw mr-2 text-gray-400\"></i>\n                                Settings\n                            </a>\n                            <a class=\"dropdown-item\" href=\"#\">\n                                <i class=\"fas fa-list fa-sm fa-fw mr-2 text-gray-400\"></i>\n                                Activity Log\n                            </a>\n                            <div class=\"dropdown-divider\"></div>\n                            <a class=\"dropdown-item\" href=\"#\" data-toggle=\"modal\" data-target=\"#logoutModal\">\n                                <i class=\"fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400\"></i>\n                                Logout\n                            </a>\n                        </div>\n                    </li>\n                </ul>\n            </nav>\n\";','','page',900,1584820269);
/*!40000 ALTER TABLE `cache_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `field` varchar(255) NOT NULL,
  `value` text NOT NULL,
  UNIQUE KEY `key` (`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES ('admin','a:1:{s:2:\"id\";i:1;}'),('theme','a:2:{s:5:\"admin\";s:7:\"default\";s:5:\"front\";s:7:\"default\";}');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `extensions`
--

DROP TABLE IF EXISTS `extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `extensions` (
  `type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `installed` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extensions`
--

LOCK TABLES `extensions` WRITE;
/*!40000 ALTER TABLE `extensions` DISABLE KEYS */;
INSERT INTO `extensions` VALUES ('core','Database',1),('core','File',1),('core','Form',1),('core','Manifest',1),('core','Matter',1),('core','Person',1),('core','Cache',1),('core','Events',1);
/*!40000 ALTER TABLE `extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `page` varchar(255) NOT NULL,
  `owner` int(25) NOT NULL,
  `backtrace` blob NOT NULL,
  `category` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `rendered` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matter`
--

DROP TABLE IF EXISTS `matter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matter` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matter`
--

LOCK TABLES `matter` WRITE;
/*!40000 ALTER TABLE `matter` DISABLE KEYS */;
/*!40000 ALTER TABLE `matter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matter__file`
--

DROP TABLE IF EXISTS `matter__file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matter__file` (
  `id` int(25) NOT NULL,
  `owner` int(25) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `filetype` varchar(255) NOT NULL DEFAULT 'file',
  `location` varchar(255) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matter__file`
--

LOCK TABLES `matter__file` WRITE;
/*!40000 ALTER TABLE `matter__file` DISABLE KEYS */;
/*!40000 ALTER TABLE `matter__file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matter__person`
--

DROP TABLE IF EXISTS `matter__person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matter__person` (
  `id` int(25) NOT NULL,
  `owner` int(25) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matter__person`
--

LOCK TABLES `matter__person` WRITE;
/*!40000 ALTER TABLE `matter__person` DISABLE KEYS */;
/*!40000 ALTER TABLE `matter__person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matter_storage`
--

DROP TABLE IF EXISTS `matter_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matter_storage` (
  `type` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `fields` blob NOT NULL,
  PRIMARY KEY (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matter_storage`
--

LOCK TABLES `matter_storage` WRITE;
/*!40000 ALTER TABLE `matter_storage` DISABLE KEYS */;
INSERT INTO `matter_storage` VALUES ('file','File','This item creates the File matter.',_binary 'a:2:{s:8:\"filetype\";a:4:{s:4:\"type\";s:7:\"varchar\";s:6:\"length\";i:255;s:13:\"default_value\";s:4:\"file\";s:4:\"form\";a:4:{s:4:\"type\";s:6:\"select\";s:4:\"name\";s:9:\"file_type\";s:5:\"label\";s:4:\"Type\";s:7:\"options\";a:3:{s:4:\"file\";s:4:\"File\";s:5:\"image\";s:5:\"Image\";s:5:\"video\";s:5:\"Video\";}}}s:8:\"location\";a:3:{s:4:\"type\";s:7:\"varchar\";s:6:\"length\";i:255;s:4:\"form\";a:3:{s:4:\"type\";s:4:\"file\";s:4:\"name\";s:13:\"file_location\";s:5:\"label\";s:8:\"Location\";}}}'),('person','Person','This item creates the Person matter.',_binary 'a:2:{s:4:\"name\";a:4:{s:4:\"type\";s:7:\"varchar\";s:6:\"length\";i:255;s:6:\"unique\";b:1;s:4:\"form\";a:2:{s:4:\"type\";s:7:\"textbox\";s:10:\"attributes\";a:1:{s:4:\"type\";s:8:\"username\";}}}s:8:\"password\";a:3:{s:4:\"type\";s:7:\"varchar\";s:6:\"length\";s:3:\"255\";s:4:\"form\";a:2:{s:4:\"type\";s:7:\"textbox\";s:10:\"attributes\";a:1:{s:4:\"type\";s:8:\"password\";}}}}');
/*!40000 ALTER TABLE `matter_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` varchar(255) NOT NULL,
  `controller` varchar(255) NOT NULL,
  `cache_type` varchar(255) NOT NULL DEFAULT 'tag',
  `cache_options` blob NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES ('cache','\\Nick\\Pages\\Cache','tag',_binary 'a:3:{s:3:\"key\";s:10:\"page.cache\";s:7:\"context\";s:4:\"page\";s:7:\"max-age\";i:1800;}\n'),('config','\\Nick\\Pages\\Config','tag',_binary 'a:3:{s:3:\"key\";s:11:\"page.config\";s:7:\"context\";s:4:\"page\";s:7:\"max-age\";i:3600;}\n'),('dashboard','\\Nick\\Pages\\Dashboard','key',_binary 'a:3:{s:3:\"key\";s:14:\"page.dashboard\";s:7:\"context\";s:4:\"page\";s:7:\"max-age\";i:1800;}\n'),('error','\\Nick\\Pages\\Error','tag',_binary 'a:3:{s:3:\"key\";s:10:\"page.error\";s:7:\"context\";s:4:\"page\";s:7:\"max-age\";i:3600;}\n'),('footer','\\Nick\\Pages\\Footer','tag',_binary 'a:3:{s:3:\"key\";s:11:\"page.footer\";s:7:\"context\";s:4:\"page\";s:7:\"max-age\";i:3600;}\n'),('header','\\Nick\\Pages\\Header','tag',_binary 'a:3:{s:3:\"key\";s:11:\"page.header\";s:7:\"context\";s:4:\"page\";s:7:\"max-age\";i:900;}\n'),('login','\\Nick\\Pages\\Login','tag',_binary 'a:3:{s:3:\"key\";s:10:\"page.login\";s:7:\"context\";s:4:\"page\";s:7:\"max-age\";i:3600;}\n');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-21 19:53:15
